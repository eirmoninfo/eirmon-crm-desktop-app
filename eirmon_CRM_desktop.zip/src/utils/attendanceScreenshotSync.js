import { getToken } from "./storage";
import { apiRequest } from "../api/http";
import { startScreenshotLoop, stopScreenshotLoop } from "./startScreenshotLoop";
import { unwrapApiBody } from "./unwrapApiBody";

let pollTimer = null;
let authToken = null;
let screenshotCfg = {};
/** True while the random-interval screenshot loop is supposed to be running */
let loopActive = false;

/** How often we re-check punch state so screenshots start soon after check-in */
const POLL_MS = 15_000;

function isPunchedIn(att) {
  if (!att || typeof att !== "object") return false;
  const inAt = att.check_in;
  const outAt = att.check_out;
  return inAt != null && inAt !== "" && (outAt == null || outAt === "");
}

async function tick() {
  const token = authToken || getToken();
  if (!token || typeof window === "undefined" || !window.api?.takeScreenshot) {
    return;
  }

  try {
    const res = await apiRequest("/attendance/today");
    const att = unwrapApiBody(res);

    const punched = isPunchedIn(att);
    const enable = screenshotCfg.enable_screenshots !== false;

    if (punched && enable) {
      if (!loopActive) {
        startScreenshotLoop(token, screenshotCfg);
        loopActive = true;
        console.log("[Tracker] Screenshots active (punched in)");
      }
    } else {
      if (loopActive) {
        stopScreenshotLoop();
        loopActive = false;
        console.log(
          "[Tracker] Screenshots stopped (punched out or not clocked in)"
        );
      }
    }
  } catch (e) {
    console.warn("[Tracker] attendance screenshot sync:", e);
  }
}

/**
 * Poll attendance and only run the screenshot upload loop while user is punched in.
 * Call from Electron bootstrap after login (replaces starting screenshots unconditionally).
 */
export function startAttendanceScreenshotSync(token, config = {}) {
  stopAttendanceScreenshotSync();
  authToken = token;
  screenshotCfg = { ...config };

  tick();
  pollTimer = setInterval(tick, POLL_MS);
}

export function stopAttendanceScreenshotSync() {
  if (pollTimer) {
    clearInterval(pollTimer);
    pollTimer = null;
  }
  stopScreenshotLoop();
  loopActive = false;
  authToken = null;
}

/**
 * Run after check-in / check-out so screenshots start or stop without waiting for the poll.
 */
export function refreshAttendanceScreenshots() {
  return tick();
}
